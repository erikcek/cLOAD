module.exports = {
	
	"google": {

		"clientID": "668998663162-6n9a7asudht92sshua2pkb0unelqecv5.apps.googleusercontent.com",
		"clientSecret": "NoV4aydCW-BIuhd4308XOWd_",
		"callbackURL": "http://localhost:9999/auth/google/callback"

	},

	"googleEmailServer": {
		"username": "erik.kandalik@student.spseke.sk",
		"password": "H2Ojezakladomzivota"
	}

}